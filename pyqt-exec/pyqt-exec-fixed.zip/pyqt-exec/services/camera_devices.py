"""Enumerates available camera devices for the camera picker dropdown.

OpenCV/most OS camera backends don't expose friendly device names the
way audio APIs do, so we probe device indices directly (0, 1, 2, ...)
and report which ones actually open successfully. This mirrors what
most lightweight camera pickers do in the absence of a proper device
enumeration API.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass

import cv2


@dataclass
class CameraDevice:
    index: int
    label: str

    def __str__(self):
        return self.label


def capture_backend() -> int:
    """Backend flag to pass to cv2.VideoCapture(index, backend).

    On Windows, OpenCV's default backend is MSMF, which delivers
    frames through its own internal async callback thread. Rapidly
    opening/releasing captures (exactly what happens here: this
    startup probe opens and releases up to 8 indices back-to-back,
    and the live editor itself starts/stops sessions on different
    indices) can race that internal callback against release()
    freeing the underlying device -- MSMF's callback then fires into
    already-freed memory, which crashes the whole process with an
    access violation (no Python exception is raised; there's nothing
    to catch). DirectShow (CAP_DSHOW) is synchronous and doesn't have
    this teardown race, so we force it on Windows. Other platforms
    keep the default (CAP_ANY) since MSMF is Windows-only anyway.
    """
    return cv2.CAP_DSHOW if sys.platform == "win32" else cv2.CAP_ANY


def list_cameras(max_index: int = 8) -> list[CameraDevice]:
    """Probes device indices 0..max_index-1 and returns the ones that
    successfully open. Each probe opens and immediately releases the
    capture, so this is a bit slow (a few hundred ms per index) but
    only runs when the user opens the dropdown / refreshes it.
    """
    backend = capture_backend()
    found: list[CameraDevice] = []
    for index in range(max_index):
        cap = cv2.VideoCapture(index, backend)
        try:
            if cap.isOpened():
                ok, _ = cap.read()
                if ok:
                    found.append(CameraDevice(index=index, label=f"Camera {index}"))
        finally:
            cap.release()
    return found
